package com.zosh.user.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
